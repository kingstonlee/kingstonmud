#ifndef __VERSION_H__
#define __VERSION_H__

extern const char SVNVersion[];

#endif /* __VERSION_H__ */
