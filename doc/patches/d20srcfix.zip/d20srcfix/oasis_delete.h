/*
 * Function prototypes defined in oasis_delete.c.
 */
void remove_room_from_memory(room_rnum rnum);
